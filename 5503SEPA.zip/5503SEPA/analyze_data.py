import csv
import sys

def analyze_csv(file_path):
    crime_types = set()
    outcomes = set()
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row['Crime type']:
                    crime_types.add(row['Crime type'])
                if row['Last outcome category']:
                    outcomes.add(row['Last outcome category'])
                    
        print("=== Unique Crime Types ===")
        for ct in sorted(crime_types):
            print(ct)
            
        print("\n=== Unique Outcomes ===")
        for o in sorted(outcomes):
            print(o)
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python analyze_data.py <csv_file>")
    else:
        analyze_csv(sys.argv[1])
