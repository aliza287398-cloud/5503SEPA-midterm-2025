import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Provides analysis features for the crime data.
 * Implements the "Exhaustive" approach (linear searches) as per Basic
 * requirements.
 */
public class Analyzer {
    private List<CrimeRecord> records;

    public Analyzer(List<CrimeRecord> records) {
        this.records = records;
    }

    /**
     * Feature 1: List all distinct crime types.
     */
    public List<String> getUniqueCrimeTypes() {
        Set<String> types = new HashSet<>();
        for (CrimeRecord r : records) {
            if (r.getCrimeType() != null && !r.getCrimeType().isEmpty()) {
                types.add(r.getCrimeType());
            }
        }
        List<String> sortedTypes = new ArrayList<>(types);
        Collections.sort(sortedTypes);
        return sortedTypes;
    }

    /**
     * Feature 2: Get all crimes of a specific type.
     */
    public List<CrimeRecord> getCrimesByType(String type) {
        List<CrimeRecord> result = new ArrayList<>();
        for (CrimeRecord r : records) {
            if (type.equalsIgnoreCase(r.getCrimeType())) {
                result.add(r);
            }
        }
        return result;
    }

    /**
     * Feature 3: Count outcomes (Successful vs Unsuccessful).
     * Successful: "Offender given a caution", "Awaiting court outcome", "Local
     * resolution"
     * Unsuccessful: "Investigation complete; no suspect identified", "Unable to
     * prosecute suspect"
     */
    public Map<String, Integer> getOutcomeStats() {
        Map<String, Integer> stats = new HashMap<>();
        int successful = 0;
        int unsuccessful = 0;
        int other = 0;

        for (CrimeRecord r : records) {
            String outcome = r.getLastOutcomeCategory();
            if (outcome == null) {
                other++;
                continue;
            }

            if (outcome.contains("caution") || outcome.contains("court") || outcome.contains("resolution")) {
                successful++;
            } else if (outcome.contains("no suspect identified") || outcome.contains("Unable to prosecute")) {
                unsuccessful++;
            } else {
                other++;
            }
        }

        stats.put("Successful", successful);
        stats.put("Unsuccessful", unsuccessful);
        stats.put("Other", other);
        return stats;
    }

    /**
     * Feature 4: Most frequent crime type for a specific month.
     */
    public String getMostFrequentCrimeType(String month) {
        Map<String, Integer> counts = new HashMap<>();
        for (CrimeRecord r : records) {
            if (month.equals(r.getMonth())) {
                String type = r.getCrimeType();
                counts.put(type, counts.getOrDefault(type, 0) + 1);
            }
        }

        String mostFrequent = null;
        int maxCount = -1;

        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            if (entry.getValue() > maxCount) {
                maxCount = entry.getValue();
                mostFrequent = entry.getKey();
            }
        }
        return mostFrequent != null ? mostFrequent + " (" + maxCount + ")" : "No data";
    }

    /**
     * Feature 6: List crimes for a specific location in reverse chronological
     * order.
     */
    public List<CrimeRecord> getCrimesByLocation(String location) {
        List<CrimeRecord> result = new ArrayList<>();
        for (CrimeRecord r : records) {
            if (location.equalsIgnoreCase(r.getLsoaName())) {
                result.add(r);
            }
        }
        // Sort by month descending (YYYY-MM)
        Collections.sort(result, (r1, r2) -> r2.getMonth().compareTo(r1.getMonth()));
        return result;
    }

    /**
     * Feature 5: Location (LSOA Name) with highest number of crimes.
     */
    public String getLocationWithMostCrimes() {
        Map<String, Integer> counts = new HashMap<>();
        for (CrimeRecord r : records) {
            String loc = r.getLsoaName();
            if (loc != null && !loc.isEmpty()) {
                counts.put(loc, counts.getOrDefault(loc, 0) + 1);
            }
        }

        String topLoc = null;
        int maxCount = -1;

        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            if (entry.getValue() > maxCount) {
                maxCount = entry.getValue();
                topLoc = entry.getKey();
            }
        }
        return topLoc != null ? topLoc + " (" + maxCount + ")" : "No data";
    }
}
