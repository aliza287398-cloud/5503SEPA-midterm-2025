/**
 * Represents a single crime record from the police data CSV.
 */
public class CrimeRecord {
    private String crimeId;
    private String month;
    private String reportedBy;
    private String fallsWithin;
    private Double longitude;
    private Double latitude;
    private String location;
    private String lsoaCode;
    private String lsoaName;
    private String crimeType;
    private String lastOutcomeCategory;
    private String context;

    public CrimeRecord(String crimeId, String month, String reportedBy, String fallsWithin, 
                       Double longitude, Double latitude, String location, String lsoaCode, 
                       String lsoaName, String crimeType, String lastOutcomeCategory, String context) {
        this.crimeId = crimeId;
        this.month = month;
        this.reportedBy = reportedBy;
        this.fallsWithin = fallsWithin;
        this.longitude = longitude;
        this.latitude = latitude;
        this.location = location;
        this.lsoaCode = lsoaCode;
        this.lsoaName = lsoaName;
        this.crimeType = crimeType;
        this.lastOutcomeCategory = lastOutcomeCategory;
        this.context = context;
    }

    // Getters
    public String getCrimeId() { return crimeId; }
    public String getMonth() { return month; }
    public String getReportedBy() { return reportedBy; }
    public String getFallsWithin() { return fallsWithin; }
    public Double getLongitude() { return longitude; }
    public Double getLatitude() { return latitude; }
    public String getLocation() { return location; }
    public String getLsoaCode() { return lsoaCode; }
    public String getLsoaName() { return lsoaName; }
    public String getCrimeType() { return crimeType; }
    public String getLastOutcomeCategory() { return lastOutcomeCategory; }
    public String getContext() { return context; }

    @Override
    public String toString() {
        return "CrimeRecord{" +
                "date='" + month + '\'' +
                ", type='" + crimeType + '\'' +
                ", location='" + location + '\'' +
                ", outcome='" + lastOutcomeCategory + '\'' +
                '}';
    }
}
