import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Police Data Analysis System (Street Crimes Edition)");
        System.out.println("Loading data...");

        DataLoader loader = new DataLoader();
        // Assuming data is in the current directory or specific subfolders
        // We'll pass the current directory "." to search recursively
        List<CrimeRecord> records = loader.loadData(".");

        if (records.isEmpty()) {
            System.out.println("No records found. Please ensure CSV files are in the directory.");
            return;
        }

        System.out.println("Data Loaded: " + records.size() + " records.");
        Analyzer analyzer = new Analyzer(records);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            printMenu();
            System.out.print("Enter choice: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    System.out.println("\n--- Unique Crime Types ---");
                    for (String type : analyzer.getUniqueCrimeTypes()) {
                        System.out.println("- " + type);
                    }
                    break;
                case "2":
                    System.out.print("Enter Crime Type to search: ");
                    String type = scanner.nextLine();
                    List<CrimeRecord> filtered = analyzer.getCrimesByType(type);
                    System.out.println("Found " + filtered.size() + " records for " + type);
                    if (!filtered.isEmpty() && filtered.size() < 10) {
                        for (CrimeRecord r : filtered)
                            System.out.println(r);
                    } else if (!filtered.isEmpty()) {
                        System.out.println("First 5 records:");
                        for (int i = 0; i < 5; i++)
                            System.out.println(filtered.get(i));
                    }
                    break;
                case "3":
                    System.out.println("\n--- Outcome Statistics ---");
                    Map<String, Integer> stats = analyzer.getOutcomeStats();
                    for (Map.Entry<String, Integer> entry : stats.entrySet()) {
                        System.out.println(entry.getKey() + ": " + entry.getValue());
                    }
                    break;
                case "4":
                    System.out.print("Enter Month (YYYY-MM): ");
                    String month = scanner.nextLine();
                    System.out.println("Most Frequent Crime: " + analyzer.getMostFrequentCrimeType(month));
                    break;
                case "5":
                    System.out.println("Location with Most Crimes: " + analyzer.getLocationWithMostCrimes());
                    break;
                case "6":
                    System.out.print("Enter Location (LSOA Name): ");
                    String loc = scanner.nextLine();
                    List<CrimeRecord> locRecords = analyzer.getCrimesByLocation(loc);
                    System.out.println("Found " + locRecords.size() + " records for " + loc);
                    if (!locRecords.isEmpty()) {
                        System.out.println("First 5 records (Reverse Chronological):");
                        for (int i = 0; i < Math.min(5, locRecords.size()); i++) {
                            System.out.println(locRecords.get(i));
                        }
                    }
                    break;
                case "0":
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
            System.out.println("\nPress Enter to continue...");
            scanner.nextLine();
        }
    }

    private static void printMenu() {
        System.out.println("\n=== MENU ===");
        System.out.println("1. List Unique Crime Types");
        System.out.println("2. Search by Crime Type");
        System.out.println("3. View Outcome Statistics");
        System.out.println("4. Most Frequent Crime by Month");
        System.out.println("5. Location with Most Crimes");
        System.out.println("6. List Crimes by Location (Chronological)");
        System.out.println("0. Exit");
    }
}
