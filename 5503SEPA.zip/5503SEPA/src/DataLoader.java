import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles loading of crime data from CSV files.
 */
public class DataLoader {

    /**
     * Loads all CSV files from the specified directory and its subdirectories.
     * 
     * @param directoryPath The path to the root directory containing data folders.
     * @return A list of all loaded CrimeRecords.
     */
    public List<CrimeRecord> loadData(String directoryPath) {
        List<CrimeRecord> records = new ArrayList<>();
        File rootDir = new File(directoryPath);

        if (!rootDir.exists() || !rootDir.isDirectory()) {
            System.err.println("Invalid directory path: " + directoryPath);
            return records;
        }

        loadRecursively(rootDir, records);
        return records;
    }

    private void loadRecursively(File dir, List<CrimeRecord> records) {
        File[] files = dir.listFiles();
        if (files == null)
            return;

        for (File file : files) {
            if (file.isDirectory()) {
                loadRecursively(file, records);
            } else if (file.getName().endsWith(".csv") && !file.getName().contains("outcomes")) {
                // Skip "outcomes" files if present, we only want street crimes for now
                // Also ensuring we are reading the street files we saw earlier
                // The user files are named like "2025-06-bedfordshire-street.csv"
                records.addAll(parseFile(file));
            }
        }
    }

    private List<CrimeRecord> parseFile(File file) {
        List<CrimeRecord> fileRecords = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean isHeader = true;
            while ((line = br.readLine()) != null) {
                if (isHeader) {
                    isHeader = false;
                    continue;
                }

                // Simple CSV parsing (splitting by comma, handling potential quotes if needed)
                // Note: This simple split might fail on complex CSVs with commas in fields.
                // For this coursework, we'll try a regex split or a simple custom parser if
                // needed.
                // The sample data didn't show complex quoted fields with commas, but let's be
                // safe.
                // Using a regex that handles quoted strings is better.
                String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);

                if (parts.length >= 12) {
                    try {
                        String crimeId = clean(parts[0]);
                        String month = clean(parts[1]);
                        String reportedBy = clean(parts[2]);
                        String fallsWithin = clean(parts[3]);
                        Double longitude = parts[4].isEmpty() ? null : Double.parseDouble(parts[4]);
                        Double latitude = parts[5].isEmpty() ? null : Double.parseDouble(parts[5]);
                        String location = clean(parts[6]);
                        String lsoaCode = clean(parts[7]);
                        String lsoaName = clean(parts[8]);
                        String crimeType = clean(parts[9]);
                        String lastOutcome = clean(parts[10]);
                        String context = clean(parts[11]);

                        fileRecords.add(new CrimeRecord(crimeId, month, reportedBy, fallsWithin,
                                longitude, latitude, location, lsoaCode, lsoaName, crimeType, lastOutcome, context));
                    } catch (NumberFormatException e) {
                        // Log error or skip row
                        // System.err.println("Skipping invalid row in " + file.getName());
                    }
                }
            }
            System.out.println("Loaded " + fileRecords.size() + " records from " + file.getName());
        } catch (IOException e) {
            System.err.println("Error reading file " + file.getName() + ": " + e.getMessage());
        }
        return fileRecords;
    }

    private String clean(String s) {
        if (s == null)
            return "";
        return s.trim();
    }
}
